//You will find that input.txt has been compressed and it created a file input.txt.gz in the current 
// directory. Now let's try to decompress the same file

var fs = require("fs");
var zlib = require('zlib');
// Decompress the file input.txt.gz to input.txt
fs.createReadStream('input.txt.gz')
.pipe(zlib.createGunzip())
.pipe(fs.createWriteStream('input.txt'));
console.log("File Decompressed.");